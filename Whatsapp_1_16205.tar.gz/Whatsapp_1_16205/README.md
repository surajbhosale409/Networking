Hello,
      kbd.c is source code for keyboard program.
      [1] to compile :  make kbd
      [2] to run     :  ./kbd

      display.c is source code  for display which will display data given from kbd.
      [1] to compile :  make display
      [2] to run     :  ./display
